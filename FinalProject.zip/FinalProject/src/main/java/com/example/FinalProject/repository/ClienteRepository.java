package com.example.FinalProject.repository;

import com.example.FinalProject.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    public List<Cliente> findByNome (String nome);

    public List<Cliente> findByEmail (String email);

    @Query("select c from Cliente c where c.nome like %?1%")
    public List<Cliente> findByPartNome (String nome);

    @Query("select c from Cliente c where c.codigo > ?1")
    public List<Cliente> findByBiggerThanId (int id);

    @Query("select c from Cliente c where c.email like %?1%")
    public List<Cliente> findByParEmail (String email);

    @Query ("select c from Cliente c where c.nome like %?1% and c.email like %?2%")
    public List<Cliente> findByNomeEmail (String nome, String email);
}
