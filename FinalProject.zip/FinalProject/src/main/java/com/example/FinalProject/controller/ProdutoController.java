package com.example.FinalProject.controller;

import com.example.FinalProject.model.Cliente;
import com.example.FinalProject.model.Produto;
import com.example.FinalProject.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping ("/apiProduto")
public class ProdutoController {

    @Autowired
    ProdutoRepository prRepo;


    @GetMapping("/getAll")
    public List<Produto> GetAllClient(){ return prRepo.findAll(); }

    @PostMapping("/insert")
    public void InsertClient(@RequestBody Produto p){
        prRepo.save(p);
    }

    @DeleteMapping("/delete")
    public void DeleteClient(@RequestBody Produto p){
        prRepo.delete(p);
    }

    @PutMapping("/update")
    public void UpdateClient(@RequestBody Produto p){
        prRepo.save(p);
    }

    @GetMapping("/findById/{codigo}")
    public Optional<Produto> FindByCodigoProduto(@PathVariable("codigo") int codigo){
        return prRepo.findById(codigo);
    }

    @GetMapping("/findByDescricao/{descricao}")
    public List<Produto> FindByDescricaoProduto(@PathVariable("descricao") String descricao){
        return prRepo.findByDescricao(descricao);
    }

    @GetMapping("/findByMarca/{marca}")
    public List<Produto> FindByMarcaProduto(@PathVariable("marca") String marca){
        return prRepo.findByMarca(marca);
    }

    @GetMapping("/findByPreco/{preco}")
    public List<Produto> FindByPrecoProduto(@PathVariable("preco") float preco){
        return prRepo.findByPreco(preco);
    }

    @GetMapping("/findByPartDescricao/{descricao}")
    public List<Produto> FindByPartDescricaoProduto(@PathVariable("descricao") String descricao){
        return prRepo.findByPartDescricao(descricao);
    }

    @GetMapping("/findByPartMarca/{marca}")
    public List<Produto> FindByPartMarcaProduto(@PathVariable("marca") String marca){
        return prRepo.findByPartMarca(marca);
    }

    @GetMapping("/findByBiggerThanPreco/{preco}")
    public List<Produto> FindByBiggerThanPrecoProduto(@PathVariable("preco") float preco){
        return prRepo.findByBiggerThanPreco(preco);
    }

    @GetMapping("/findBySmallerThanPreco/{preco}")
    public List<Produto> FindBySmallerThanPrecoProduto(@PathVariable("preco") float preco){
        return prRepo.findBySmallerThanPreco(preco);
    }

    @GetMapping ("/findByDescricaoMarca/{descricao}/{marca}")
    public List<Produto> FindByPartDescricaoMarca (@PathVariable("descricao") String descricao, @PathVariable("marca") String marca){
        return prRepo.findByDescricaoMarca(descricao, marca);
    }

    @GetMapping ("/findByDescricaoPreco/{descricao}/{preco}")
    public List<Produto> FindByPartDescricaoPreco (@PathVariable("descricao") String descricao, @PathVariable("preco") float preco){
        return prRepo.findByDescricaoPreco(descricao, preco);
    }
}
