package com.example.FinalProject.controller;

import com.example.FinalProject.model.Cliente;
import com.example.FinalProject.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/apiCliente")
public class ClienteController {

    @Autowired
    ClienteRepository clRepo;

    @GetMapping("/getAll")
    public List<Cliente> GetAllClient(){ return clRepo.findAll(); }

    @PostMapping("/insert")
    public void InsertClient(@RequestBody Cliente c){
        clRepo.save(c);
    }

    @DeleteMapping("/delete")
    public void DeleteClient(@RequestBody Cliente c){
        clRepo.delete(c);
    }

    @PutMapping("/update")
    public void UpdateClient(@RequestBody Cliente c){
        clRepo.save(c);
    }

    @GetMapping("/findById/{id}")
    public Optional<Cliente> FindByIdClient(@PathVariable("id") int id){
        return clRepo.findById(id);
    }

    @GetMapping("/findByName/{nome}")
    public List<Cliente> FindByNomeClient(@PathVariable("nome") String nome){
        return clRepo.findByNome(nome);
    }

    @GetMapping("/findByEmail/{email}")
    public List<Cliente> FindByEmailClient(@PathVariable("email") String email){
        return clRepo.findByEmail(email);
    }

    @GetMapping("/findByPartName/{nome}")
    public List<Cliente> FindByPartNameClient(@PathVariable("nome") String nome){
        return clRepo.findByPartNome(nome);
    }

    @GetMapping("/findByBiggerThanId/{id}")
    public List<Cliente> FindByBiggerThanIdClient(@PathVariable("id") int id){
        return clRepo.findByBiggerThanId(id);
    }

    @GetMapping("/findByPartEmail/{email}")
    public List<Cliente> FindByPartEmailClient(@PathVariable("email") String email){
        return clRepo.findByParEmail(email);
    }

    @GetMapping ("/findByNameEmail/{nome}/{email}")
    public List<Cliente> FindByPartNomeEmail (@PathVariable("nome") String nome, @PathVariable("email") String email){
        return clRepo.findByNomeEmail(nome, email);
    }

}
