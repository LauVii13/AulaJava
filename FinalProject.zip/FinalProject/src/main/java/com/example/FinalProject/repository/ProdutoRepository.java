package com.example.FinalProject.repository;

import com.example.FinalProject.model.Cliente;
import com.example.FinalProject.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {

    public List<Produto> findByDescricao (String descricao);

    public List<Produto> findByMarca (String Marca);

    public List<Produto> findByPreco (float preco);

    @Query("select p from Produto p where p.descricao like %?1%")
    public List<Produto> findByPartDescricao (String descricao);

    @Query("select p from Produto p where p.marca like %?1%")
    public List<Produto> findByPartMarca (String marca);

    @Query("select p from Produto p where p.preco > ?1")
    public List<Produto> findByBiggerThanPreco (float preco);

    @Query("select p from Produto p where p.preco < ?1")
    public List<Produto> findBySmallerThanPreco (float preco);

    @Query ("select p from Produto p where p.descricao like %?1% and p.marca like %?2%")
    public List<Produto> findByDescricaoMarca (String descricao, String marca);

    @Query ("select p from Produto p where p.descricao like %?1% and p.preco < ?2")
    public List<Produto> findByDescricaoPreco (String descricao, float preco);
}
