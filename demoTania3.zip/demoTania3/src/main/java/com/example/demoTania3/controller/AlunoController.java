package com.example.demoTania3.controller;

import com.example.demoTania3.model.Aluno;
import com.example.demoTania3.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping (value="/apiAluno")
public class AlunoController {

    @Autowired
    AlunoRepository alRepo;

    @GetMapping (value="/todos")
    public List<Aluno> buscarTodos()
    {
        return  alRepo.findAll();
    }

    @GetMapping ("/aluno/{ra}")
    public Optional<Aluno> buscarPorId(@PathVariable(value="ra") int ra)
    {
        return alRepo.findById(ra);
    }

    @PostMapping("/inserirAluno")
    public void inserirAluno (@RequestBody Aluno al)
    {
        alRepo.save(al);
    }

    @DeleteMapping ("/remover")
    public void removerAluno (@RequestBody Aluno al)
    {
        alRepo.delete(al);
    }

    @PutMapping ("/atualizar")
    public void atualizarAluno (@RequestBody Aluno al)
    {
        alRepo.save(al);
    }

    @GetMapping ("/nome/{nome}")
    public List<Aluno> listarPorNome
            (@PathVariable (value="nome") String nome)
    {
        return alRepo.findByNome(nome);
    }

    @GetMapping ("/raMaior/{ra}")
    public List<Aluno> listarPorRaMaior
            (@PathVariable (value="ra") int ra)
    {
        return alRepo.findByRaMaior(ra);
    }

    @GetMapping ("/nomeEspec/{nome}")
    public List<Aluno> listarPorNomeEspec
            (@PathVariable (value="nome") String nome)
    {
        return alRepo.findByNomeEspec(nome);
    }

    @GetMapping ("/raNome/{ra}/{nome}")
    public List<String> listarRANome (@PathVariable(value = "ra") int ra, @PathVariable(value = "nome") String nome){
        return alRepo.apenasNome(ra, nome);
    }


}
